from django.apps import AppConfig


class ConsultantApiConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "consultant_api"
