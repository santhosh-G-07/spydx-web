from huggingface_hub import snapshot_download
import spacy

# Step 1: Download the model from Hugging Face (done only once)
model_path = snapshot_download("amjad-awad/skill-extractor", repo_type="model")

# Step 2: Load the model in spaCy from the downloaded folder (done once per app start)
nlp = spacy.load(model_path)

def extract_skills_from_text(text):
    # Run the spaCy model on your text
    doc = nlp(text)
    # Extract entities labeled as skills
    skills = [ent.text for ent in doc.ents if "SKILLS" in ent.label_]
    return skills
