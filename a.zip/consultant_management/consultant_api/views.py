# consultant_api/views.py

from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import Consultant


def home_view(request):
    return render(request, 'frontend/home.html')

def consultant_signup(request):
    if request.method == 'POST':
        name = request.POST.get('name')  # for User first_name
        email = request.POST.get('email')
        password = request.POST.get('password')

        dob = request.POST.get('dob')  # Expecting date string from form input (e.g., 'YYYY-MM-DD')
        address = request.POST.get('address')
        job_role = request.POST.get('job_role')

        # Create the User
        user = User.objects.create_user(
            username=email,  # username is required
            email=email,
            password=password,
            first_name=name  # store name in first_name
        )

        # Create Consultant with these extra fields
        Consultant.objects.create(
            user=user,
            dob=dob if dob else None,
            address=address if address else '',
            job_role=job_role if job_role else ''
        )

        return redirect('consultant_login')

    return render(request, 'frontend/consultant/signup.html')


# ----------------- Consultant Login -----------------
def consultant_login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        user = authenticate(request, username=email, password=password)
        if user is not None:
            login(request, user)
            return redirect('consultant_dashboard')
        else:
            return render(request, 'frontend/consultant/login.html', {
                'error': 'Invalid email or password'
            })

    return render(request, 'frontend/consultant/login.html')


# ----------------- Consultant Logout -----------------
def consultant_logout(request):
    logout(request)
    return redirect('consultant_login')


# ----------------- Consultant Dashboard -----------------
@login_required(login_url='consultant_login')
def consultant_dashboard_view(request):
    consultant = request.user.consultant
    return render(request, 'frontend/consultant/dashboard.html', {
        'consultant': consultant
    })


# ----------------- Admin placeholders -----------------
def admin_login(request):
    return render(request, 'frontend/admin/login.html')

def admin_signup(request):
    return render(request, 'frontend/admin/signup.html')

def admin_dashboard_view(request):
    return render(request, 'frontend/admin/dashboard.html')
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.shortcuts import render

@login_required
def consultant_profile(request):
    return render(request, 'frontend/consultant/profile.html')

@login_required
def consultant_projects(request):
    return render(request, 'frontend/consultant/projects.html')

@login_required
def consultant_resume(request):
    return render(request, 'frontend/consultant/resume.html')

@login_required
def consultant_notifications(request):
    return render(request, 'frontend/consultant/notifications.html')

@login_required
def consultant_tracker(request):
    return render(request, 'frontend/consultant/tracker.html')

@login_required
def consultant_reports(request):
    return render(request, 'frontend/consultant/reports.html')

@login_required
def consultant_settings(request):
    return render(request, 'frontend/consultant/settings.html')


import os
from django.conf import settings
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .forms import ResumeUploadForm
from .models import ResumeUpload, Project
from .utils import extract_text_from_resume, parse_projects_nlp
import os
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect

# Import your utilities and models
from .forms import ResumeUploadForm
from .models import Project, Consultant
from .utils import extract_text_from_resume, parse_projects_nlp, calculate_skill_match_percentage
from .skill_extractor import extract_skills_from_text

@login_required(login_url='consultant_login')
def resume_upload_view(request):
    if request.method == 'POST':
        form = ResumeUploadForm(request.POST, request.FILES)
        if form.is_valid():
            # Save the uploaded resume instance
            resume_instance = form.save(commit=False)
            resume_instance.user = request.user
            resume_instance.save()

            # Full path to saved resume file
            file_path = os.path.join(settings.MEDIA_ROOT, resume_instance.file.name)

            # Extract plain text from resume
            extracted_text = extract_text_from_resume(file_path)

            # Parse projects using existing NLP logic
            parsed_projects = parse_projects_nlp(extracted_text)

            max_length = Project._meta.get_field('name').max_length
            consultant = request.user.consultant

            # Update or create projects
            for proj in parsed_projects:
                name = proj['name'][:max_length]  # truncate safely if needed
                description = proj['description']

                Project.objects.update_or_create(
                    consultant=consultant,
                    name=name,
                    defaults={'description': description}
                )

            # --- New Skill Extraction & Matching Logic ---

            # Extract skills using your skill extraction model (spaCy or other)
            extracted_skills = extract_skills_from_text(extracted_text)
            

            # Get required skills from user's job role
            job_role_skills = consultant.job_role.skills.all()

            # Calculate skill match percentage and matched/missing skills
            skill_match_percentage, matched_skills, missing_skills = calculate_skill_match_percentage(
                extracted_skills,
                job_role_skills
            )

            # Save or update these values in the consultant model (add these fields in your model!)
            consultant.skill_match_percentage = skill_match_percentage
            # Optional: you can serialize matched_skills and missing_skills as JSON strings and save
            # For simplicity, only the percentage is saved here
            consultant.save()

            # Optionally pass match info via Django messages or session if you want to show after redirect
            # But mostly dashboard should read these stored values

            return redirect('consultant_dashboard')  # Redirect to dashboard or wherever

    else:
        form = ResumeUploadForm()

    user_resumes = ResumeUpload.objects.filter(user=request.user).order_by('-uploaded_at')
    return render(request, 'frontend/consultant/resume_upload.html', {'form': form, 'user_resumes': user_resumes})



from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Project
from .forms import ProjectForm

@login_required(login_url='consultant_login')
def project_list_view(request):
    consultant = request.user.consultant
    projects = Project.objects.filter(consultant=consultant).order_by('-start_date')
    return render(request, 'frontend/consultant/projects.html', {'projects': projects})

@login_required(login_url='consultant_login')
def project_add_view(request):
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            project = form.save(commit=False)
            project.consultant = request.user.consultant
            project.save()
            return redirect('consultant_projects')  # URL name for project list
    else:
        form = ProjectForm()
    return render(request, 'frontend/consultant/project_add.html', {'form': form})
 

 #to count the total proj
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from .models import Project

@login_required(login_url='consultant_login')
def consultant_dashboard_view(request):
    consultant = request.user.consultant
    total_projects = Project.objects.filter(consultant=consultant).count()

    context = {
        'total_projects': total_projects,
        # add other dashboard context here
    }
    return render(request, 'frontend/consultant/dashboard.html', context)


# reo[rt]

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import AttendanceReportUploadForm
from .models import AttendanceReport
from .utils import parse_teams_attendance_file

@login_required(login_url='consultant_login')
def attendance_report_view(request):
    consultant = request.user.consultant

    # Check if a report already exists for this consultant, get latest one if multiple
    existing_report = AttendanceReport.objects.filter(consultant=consultant).order_by('-uploaded_at').first()

    if request.method == 'POST':
        form = AttendanceReportUploadForm(request.POST, request.FILES)
        if form.is_valid():
            file = form.cleaned_data['file']
            try:
                # Parse uploaded attendance file
                summary = parse_teams_attendance_file(file)

                # Save uploaded file and summary to DB
                report = AttendanceReport.objects.create(
                    consultant=consultant,
                    file=file,
                    summary_data=summary
                )
                messages.success(request, "Attendance report uploaded and processed successfully.")
                return redirect('consultant_reports')  # Your reports page URL name

            except Exception as e:
                messages.error(request, f"Error processing attendance report: {str(e)}")

    else:
        form = AttendanceReportUploadForm()

    context = {
        'form': form,
        'report': existing_report,
        'summary': existing_report.summary_data if existing_report else None,
    }

    return render(request, 'frontend/consultant/attendance_report.html', context)


from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from .forms import ConsultantProfileUpdateForm

@login_required(login_url='consultant_login')
def profile_view(request):
    consultant = request.user.consultant
    # ...
    if request.method == 'POST':
        form = ConsultantProfileUpdateForm(request.POST, instance=consultant)
        if form.is_valid():
            form.save()
            return redirect('consultant_profile')
    else:
        form = ConsultantProfileUpdateForm(instance=consultant)

    context = {
        'consultant': consultant,
        'form': form,
        # ...
    }
    return render(request, 'frontend/consultant/profile.html', context)


from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import JobRole
from .utils import extract_text_from_resume, calculate_skill_match_percentage
from .skill_extractor import extract_skills_from_text



from django.contrib.auth.decorators import login_required
from .models import JobRole
from .utils import extract_text_from_resume, calculate_skill_match_percentage

from .skill_extractor import extract_skills_from_text
import os
from django.conf import settings
@login_required
def dashboard_view(request):
    consultant = request.user.consultant
    required_skills = consultant.job_role.skills.all()

    # Read previously computed data
    skill_match_percentage = getattr(consultant, 'skill_match_percentage', 0.0)
    matched_skills = getattr(consultant, 'matched_skills', [])
    missing_skills = getattr(consultant, 'missing_skills', [])

    context = {
        'skill_match_percentage': skill_match_percentage,
        'matched_skills': matched_skills,
        'missing_skills': missing_skills,
        'required_skills': required_skills,
    }
    return render(request, 'frontend/consultant/dashboard.html', context)
