from django import forms
from django.contrib.auth.models import User
from .models import Consultant

from django import forms
from .models import ResumeUpload

class ResumeUploadForm(forms.ModelForm):
    class Meta:
        model = ResumeUpload
        fields = ['file']
from django import forms
from .models import Project

class ProjectForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ['name', 'start_date', 'end_date', 'description']
        widgets = {
            'start_date': forms.DateInput(attrs={'type': 'date'}),
            'end_date': forms.DateInput(attrs={'type': 'date'}),
        }
from django import forms

class AttendanceReportUploadForm(forms.Form):
    file = forms.FileField(label="Upload Attendance Report (CSV or Excel)")


from django import forms
from .models import Consultant
from django import forms
from .models import Consultant

class ConsultantProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = Consultant
        fields = ['dob', 'job_role', 'phone', 'address']
        widgets = {
            'dob': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'job_role': forms.TextInput(attrs={'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }
