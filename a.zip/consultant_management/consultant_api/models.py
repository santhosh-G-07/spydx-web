from django.db import models
from django.contrib.auth.models import User


# Consultant profile linked to default Django User
from django.db import models
from django.contrib.auth.models import User
from datetime import date

from django.contrib.postgres.fields import ArrayField
from django.db import models

class Consultant(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    dob = models.DateField(null=True, blank=True)
    job_role = models.CharField(max_length=255, blank=True,null=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    skill_match_percentage = models.FloatField(default=0.0)
    address = models.TextField(blank=True,null=True)
    
    # Store matched and missing skills as JSON arrays (Django 3.1+ native JSONField):
    matched_skills = models.JSONField(default=list, blank=True)
    missing_skills = models.JSONField(default=list, blank=True)

    @property
    def age(self):
        if self.dob:
            today = date.today()
            return today.year - self.dob.year - ((today.month, today.day) < (self.dob.month, self.dob.day))
        return None



from django.db import models
from django.contrib.auth.models import User

class ResumeUpload(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='resumes')
    file = models.FileField(upload_to='resumes/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username}'s Resume ({self.file.name})"



from django.db import models

class Project(models.Model):
    consultant = models.ForeignKey('Consultant', on_delete=models.CASCADE, related_name='projects')
    name = models.CharField(max_length=255)

    description = models.TextField(blank=True)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)

    def __str__(self):
        return self.name

from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
  # or use models.JSONField in Django 3.1+

class AttendanceReport(models.Model):
    consultant = models.ForeignKey('Consultant', on_delete=models.CASCADE)
    file = models.FileField(upload_to='attendance_reports/')
    uploaded_at = models.DateTimeField(default=timezone.now)
    
    # Store processed attendance summary data (optional, you may adjust structure)
    summary_data = models.JSONField(null=True, blank=True)
 # if Django 3.1+, or use jsonfield.JSONField
    
    def __str__(self):
        return f"Attendance Report for {self.consultant.user.username} at {self.uploaded_at.strftime('%Y-%m-%d %H:%M:%S')}"

#skilllllllllllllllll


from django.db import models

class Skill(models.Model):
    name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name

class JobRole(models.Model):
    name = models.CharField(max_length=100, unique=True)
    skills = models.ManyToManyField(Skill, related_name='job_roles')

    def __str__(self):
        return self.name
