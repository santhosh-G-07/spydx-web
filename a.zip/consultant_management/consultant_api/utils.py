import os
import re
import pdfplumber
import spacy
from huggingface_hub import snapshot_download
from docx import Document

# =======================
# Resume text extraction
# =======================

def extract_text_from_pdf(file_path):
    """Extract full text from a PDF file using pdfplumber."""
    text = ''
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + '\n'
    return text

def extract_text_from_docx(file_path):
    """Extract plain text from a DOCX file using python-docx."""
    doc = Document(file_path)
    return '\n'.join([para.text for para in doc.paragraphs])

def extract_text_from_resume(file_path):
    """Extract text from resume file based on its extension"""
    ext = os.path.splitext(file_path)[1].lower()
    if ext == '.pdf':
        return extract_text_from_pdf(file_path)
    elif ext == '.docx':
        return extract_text_from_docx(file_path)
    else:
        raise ValueError("Unsupported file format. Please upload PDF or DOCX resumes.")

# =======================
# Projects section parsing
# =======================

def extract_projects_section(text):
    """
    Extract 'Projects' section from resume text.
    Searches for headings like 'Projects', 'Professional Projects', etc.
    """
    pattern = re.compile(
        r'(Projects|Professional Projects|Relevant Projects)(.*?)(\n[A-Z][a-zA-Z ]*?:|\Z)', 
        re.DOTALL | re.IGNORECASE
    )
    match = pattern.search(text)
    if match:
        projects_text = match.group(2).strip()
        return projects_text
    return ''

def parse_projects(projects_text):
    """
    Parse given projects text into individual projects.
    Each project is on separate line: format "Name: Description" or "Name - Description".
    """
    projects = []
    lines = projects_text.splitlines()

    for line in lines:
        line = line.strip()
        if not line:
            continue

        if ':' in line:
            name, description = line.split(':', 1)
        elif '-' in line:
            name, description = line.split('-', 1)
        else:
            name = line
            description = ''

        projects.append({
            'name': name.strip(),
            'description': description.strip(),
        })
    return projects

def parse_projects_nlp(text):
    """Extract projects section and parse projects from full resume text"""
    projects_section = extract_projects_section(text)
    if not projects_section:
        return []
    return parse_projects(projects_section)

# =======================
# Skill Extraction setup
# =======================

# Download and load the Hugging Face spaCy skill extractor model (runs once, cached locally)
_model_path = snapshot_download("amjad-awad/skill-extractor", repo_type="model")
_nlp = spacy.load(_model_path)

def extract_skills_from_text(text):
    """
    Extract skill entities from given text using the spaCy skill extractor.
    The entity label for skills is assumed to contain "SKILLS".
    """
    doc = _nlp(text)
    skills = [ent.text for ent in doc.ents if "SKILLS" in ent.label_]
    return skills

# =======================
# Skill match calculation
# =======================

def calculate_skill_match_percentage(extracted_skills, required_skills_queryset):
    """
    Calculate skill match percentage.
    - extracted_skills: list of strings extracted from resume
    - required_skills_queryset: Django queryset of Skill objects linked to job role
    Returns tuple: (percentage: float, matched_skills: set, missing_skills: set)
    """
    required_skills = set(skill.name.lower() for skill in required_skills_queryset)
    extracted_skills_set = set(skill.lower() for skill in extracted_skills)

    matched_skills = extracted_skills_set.intersection(required_skills)
    total_required = len(required_skills)

    if total_required == 0:
        return 0.0, set(), required_skills  # No defined skills, consider 0%

    percentage = (len(matched_skills) / total_required) * 100
    missing_skills = required_skills.difference(matched_skills)

    return round(percentage, 2), matched_skills, missing_skills
